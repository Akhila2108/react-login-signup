import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './Dashboard';
import LoginPage from './Login';
import SignupPage from './Signup';
import './App.css';

function App() {
  return (
    <Router>
        <Routes>
          <Route path="/signup" Component={SignupPage} />
          <Route path="/login" Component={LoginPage} />
          <Route path="/" Component={LoginPage} />
          <Route path="/dashboard" element={<Dashboard />}></Route>
        </Routes>
    </Router>
  );
}

export default App;
