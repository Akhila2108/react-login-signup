import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
import './login.css';
import { toast } from 'react-toastify';

function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    const userlogindetails = {
      username,
      password,
    };

    try {
      const response = await axios.post("http://localhost:8080/api/Logindata", { userlogindetails });

      if (response.status === 200) {
        const usersDetails = response.data.users_details;
        alert("Login Successful");
        localStorage.setItem("user",userlogindetails.username)
        // Redirect to Dashboard with user details
        navigate('/dashboard', { state: { usersDetails } });
      } else if (response.status === 401) {
        alert("Invalid credentials");
      } else {
        alert("Error logging in.");
      }
    } catch (error) {
      console.error("Error during login:", error);
    }
  };
  
  return (
    <div className="login-container">
      <form className="login-form">
        <h2>Login</h2>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={e => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={e => setPassword(e.target.value)}
        />
        <button type="submit" onClick={handleLogin}>Login</button>
        <p className="signup-link">
          Don't have an account? <Link to="/signup">Sign Up</Link>
        </p>
      </form>
    </div>
  );
}

export default LoginPage;
